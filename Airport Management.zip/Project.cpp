#include <iostream>
#include <fstream>
#include <string.h>
#include <string>
#include <cstdlib>
#include <ctime>
#include <conio.h>

using namespace std;


class Person
{
    protected:
        int ID;
        long long CNIC;
        string Name;
	    string Username;
	    string Password;
	    string Pin;
        string Info;
    public:
        Person()
        {
            Name = "NULL";
            ID = 0;
            CNIC = 0;
            Pin = "NULL";
            Username = "NULL";
            Password = "NULL";
            Info = "NULL";
        }
        Person(string N, int id, long long cnic, string pin,string uname,string pass,string info)
        {
            Name = N;
            ID = 0;
            CNIC = 0;
            Pin = pin;
            Username = uname;
            Password = pass;
            Info = info;
        }
        Person(string N,long long cnic)
        {
            Name = N;
            CNIC = cnic;
        }
        void set_Name(string N)
        {
            Name = N;
        }
        void set_ID(int id)
        {
            ID = id;
        }
        void set_Info(string info)
        {
            Info = info;
        }
        void set_CNIC(long long cnic)
        {
            CNIC = cnic;
        }
        void set_Pin(string pin)
        {
            Pin = pin;
        }
        void set_username(string uname)
        {
            Username = uname;
        }
        void set_Password(string pass)
        {
           Password = pass;
        }
        string get_Name()
        {
            return Name;
        }
        int get_ID()
        {
            return ID;
        }
        long long get_CNIC()
        {
            return CNIC;
        }
        string get_Pin()
        {
            return Pin;
        }
        string get_username()
        {
            return Username;
        }
        string get_Info()
        {
            return Info;
        }
        string get_Password()
        {
            return Password;
        }
        void setAcc(string Uname, string pass, string pin)
        {
            Username = Uname;
            Password = pass;
            Pin = pin;
        }
};


class Admin: public Person
{
    private:
        string Designation;
    public:
        Admin()
        {
            Designation = "NULL";
        }
        Admin(string Desig, string N, int id,long long cnic, string pin,string uname,string pass,string info):Person(N,id,cnic,uname,pass,pin,info)
        {
            Designation = Desig;
        }
        void set_Designation(string Desig)
        {
            Designation = Desig;
        }
        string get_Designation()
        {
            return Designation;
        }
        void set_AName(string N)
        {
            Name = N;
        }
        string get_AName()
        {
            return Name;
        }
        void set_AID(int id)
        {
            ID = id;
        }
        int get_AID()
        {
            return ID;
        }
        void set_ACNIC(long long cnic)
        {
            CNIC = cnic;
        }
        long long get_Acnic()
        {
            return CNIC;
        }
        bool login()
        {
            bool Check1 = false;
            bool Check2 = false;
            string uname;
            string pass;
            fstream File;
            string temps;
            string info;
            File.open("Admin.txt");
            char* temp;
            temp = new char[40];
            
            Failed:
            cout<<"Enter Username"<<endl;
            cin>>uname;
            
            while(!(File.eof()))
            {
                getline(File,temps);
                int pos = temps.find("\t");
                string name = temps.substr(0,pos);

                if(name == uname)
                {
                    cout<<"\nUser found"<<endl;
                    Check1 = true;
                    break;
                }
                else
                {
                    cout<<"\nUser not found"<<endl;
                    goto Failed;
                }
            }
                if(Check1 == true)
                {
                    cout<<"Enter Passowrd"<<endl;
                    string pass;
                    char F[32];
                    char a;
                    int i=0;
                    while (1)
                    {
                        a=getch();
                        
                        if (a>=32&&a<=126)
                        {
                            F[i]=a;
                            i++;
                            cout<<"*";
                        }
                        
                        if (a=='\b'&&i>=1)
                        {
                            cout<<"\b \b";
                            i--;
                        }
                        
                        if (a=='\r')
                        {
                            F[i]='\0';
                            break;
                        }
                    }
                    pass=F;

                    int pos = temps.find("\t");
                    string name = temps.substr(pos+1,8);
                    if(name == pass)
                        return true;
                    else
                    return false;
                }
        }
};

class Country
{
    protected:
        int Cnt_ID;
        string Cnt_Name;
        bool Covid_status;
    public:
        Country()
        {
            Cnt_ID = 0;
            Cnt_Name = "NULL";
            Covid_status = false;
        }
        Country(int id, string name)
        {
            Cnt_ID = id;
            Cnt_Name = name;
        }
        void set_Country(int id, string name, bool Cstatus)
        {
            Cnt_ID = id;
            Cnt_Name = name;
            Covid_status = Cstatus;
        }
        int get_CntID()
        {
            return Cnt_ID;
        }
        string get_CntName()
        {
            return Cnt_Name;
        }
};

class Travel_History
{
    private:
        int Day,Month,Year;
        Country country;
    public:
        Travel_History()
        {
            Day = 0;
            Month = 0;
            Year = 0;
        }
        Travel_History(int d, int m, int y)
        {
            Day = d;
            Month = m;
            Year = y;
        }
        void set_Date(int d, int m, int y)
        {
            Day = d;
            Month = m;
            Year = y;
        }
        int get_Date()
        {
            return Day,Month,Year;
        }
};

class Visa
{
    private:
        int Day,Month,Year;
        string Cvisa;
        string Nationality;
        Country country;
    public:
        Visa()
        {
            Nationality = "NULL"; 
        }
        Visa(int d, int m ,int y, string VT, string Nation)
        {
            Day = d;
            Month = m;
            Year = y;
            Cvisa = VT;
            Nationality = Nation;
        }
        void set_Nationality(string N)
        {
            Nationality = N;
        }
        void setcvisa(string VT)
        {
            Cvisa = VT;
        }
        void set_Date(int d, int m, int y)
        {
            Day = d;
            Month = m;
            Year = y;
        }
        string get_Nationality()
        {
            return Nationality;
        }
        int get_date()
        {
            return Day,Month,Year;
        }
        string get_cvisa()
        {
            return Cvisa;
        }
};

class Passport: public Person
{
    private:
        string Passport_Name;
        Visa *visa;
    public:
        Passport()
        {
            Passport_Name = "NULL";
            this->visa = new Visa();
        }
        Passport(int Pass_N, string N, long long cnic): Person(N,cnic)
        {
            Passport_Name = Pass_N;
        }
        void set_PassNO(long Pass_No)
        {
            Passport_Name = Pass_No;
        }
        string get_PassnO()
        {
            return Passport_Name;
        }
        ~Passport()
        {
            delete visa;
        }

};

class Passenger: public Person
{
    private:
        string Type;
        Passport *Pass;
        Travel_History* Trav_his;
    public:
        Passenger()
        {
            Type = "NULL";
            this->Pass = new Passport();
            this->Trav_his = new Travel_History();

        }
        Passenger(string t, string N, int id, long long cnic,string uname,string pass,string pin,string info): Person(N,id,cnic,uname,pass,pin,info)
        {
            Type = t;
        }
        void set_PName(string N)
        {
            Name = N;
        }
        string get_PName()
        {
            return Name;
        }
        void set_PID(int id)
        {
            ID = id;
        }
        int get_PID()
        {
            return ID;
        }
        void set_PCNIC(long long cnic)
        {
            CNIC = cnic;
        }
        long long get_Pcnic()
        {
            return CNIC;
        }
        void set_Type(string T)
        {
            Type = T;
        }
        void set_Pin(string pin)
        {
            Pin = pin;
        }
        string get_pin()
        {
            return Pin;
        }
        string get_Type()
        {
            return Type;
        }
        string get_Username()
        {
            return Username;
        }
        string get_Password()
        {
            return Password;
        }
        void setAcc(string Uname, string pass, string pin, long long cnic)
        {
            Username = Uname;
            Password = pass;
            Pin = pin;
            CNIC = cnic;
        }
        bool Login()
        {
            bool Check1 = false;
            bool Check2 = false;
            string uname;
            string pass;
            fstream File;
            string temps;
            string info;
            File.open("Passenger.txt");
            char* temp;
            temp = new char[40];
            
            Failed:
            cout<<"Enter Username"<<endl;
            cin>>uname;
            
            while(!(File.eof()))
            {
                getline(File,temps);
                int pos = temps.find("\t");
                string name = temps.substr(0,pos);

                if(name == uname)
                {
                    cout<<"User found"<<endl;
                    Check1 = true;
                    break;
                }
            }
                if(Check1 == true)
                {
                    cout<<"Enter Passowrd"<<endl;
                    string pass;
                    char F[32];
                    char a;
                    int i=0;
                    while (1)
                    {
                        a=getch();
                        
                        if (a>=32&&a<=126)
                        {
                            F[i]=a;
                            i++;
                            cout<<"*";
                        }
                        
                        if (a=='\b'&&i>=1)
                        {
                            cout<<"\b \b";
                            i--;
                        }
                        
                        if (a=='\r')
                        {
                            F[i]='\0';
                            break;
                        }
                    }
                    pass=F;
                    int pos = temps.find("\t");
                    string name = temps.substr(pos+1,8);

                    if(name == pass)
                        return true;
                    else
                    return false;

                }
                else
                {
                    goto Failed;
                }
        }      
        void Register()
        {
            string uname;
            string pass;
            long long cnic;
            string pin;
            bool Pass_Check1 = false;
            bool Pass_Check2 = false;
            bool Pass_Check3 = false;
            bool Pass_Check4 = false;
            bool Pass_Check5 = false;
            char c;
            cout<<"\n\t\tCreate an Account"<<endl;

            cout<<"\nEnter Username"<<endl;
            cin>>uname;
            Cnic:
            cout<<"\nEnter CNIC"<<endl;
            cin>>cnic;
            string check = to_string(cnic);
            int Size1 = check.length();

            if(!(Size1==13))
            {
                cout<<"Invalid CNIC"<<endl;
                goto Cnic;
            }
            Password:
            cout<<"\nEnter Password"<<endl;
            cin>>pass;

            int Size = pass.length();

            if(Size<8)//Password Size Check
            {
                Pass_Check1 = true;
            }           
            for(int i = 0; i<Size; i++)//Upper Case Letters Check
            {
                if(isupper(pass[i]))
                {
                    Pass_Check2 = true;
                    break;
                }
            }
            for(int i = 0; i<Size; i++)//Lower Case Letters Check
            {
                if(islower(pass[i]))
                {
                    Pass_Check3 = true;
                    break;
                }
                
            }
            for(int i = 0; i<Size; i++)
            {
                
                if(isdigit(pass[i]))// Digit Check
                {
                    Pass_Check4 = true;
                    break;
                }
               
            }
            for(int i = 0; i<Size; i++)//Special Character Check
            {
                if(!(isdigit(pass[i]) && islower(pass[i]) && isupper(pass[i])))
                {
                    Pass_Check5 = true;
                    break;
                }
            }

            if(Pass_Check1 == true && Pass_Check2 == true && Pass_Check3 == true && Pass_Check4 == true && Pass_Check5)
            {
                cout<<"\nEnter a pin so that you can update your password in the future"<<endl;
                cin>>pin;
                fstream File;
                File.open("Passenger.txt",ios::app);

                File << uname<<"\t"<<pass<<"\t"<<"\t"<<pin<<"\t"<<cnic<<"\n";
            }
            else
            {
                cout<<"\nInvaid Password: Password must contain a lower case letter, upper case letter, a special character and a digit"<<endl;
                goto Password;
            }
            
        }
        ~Passenger()
        {
            delete Pass,Trav_his;
        }
};

class Aeroplane
{
    private:
        int Ap_ID;
    public:
        Aeroplane()
        {
            Ap_ID = 0;
        }
        Aeroplane(int id)
        {
            Ap_ID = id;
        }
        void set_Apid(int id)
        {
            Ap_ID = id;
        }
        int get_ApID()
        {
            return Ap_ID;
        }
};

class Runway
{
    private:
        int R_ID;
        string R_Name;
        bool R_status;
    public:
        Runway()
        {
            R_ID = 0;
            R_Name = "NULL";
            R_status = true;
        }
        Runway(int id, string name)
        {
            R_ID = id;
            R_Name = name;
        }
        void set_Runway(int rid, string rname)
        {
            R_ID = rid;
            R_Name = rname;
        }
        int get_RID()
        {
            return R_ID;
        }
        string get_RName()
        {
            return R_Name;
        }

};


class Airport
{
    private:
        int A_ID;
        string A_Name;
        Runway *R;
    public:
        Airport()
        {
            A_ID = 0;
            A_Name = "NULL";
            R = new Runway[2];
            R[0].set_Runway(1,"Norh");
            R[1].set_Runway(2,"South");
        }
        Airport(int id, string name)
        {
            A_ID = id;
            A_Name = name;
        }
        void set_A(int aid, string name)
        {
            A_ID = aid;
            A_Name = name;
        }
        int get_AID()
        {
            return A_ID;
        }
        string get_AName()
        {
            return A_Name;
        }
        ~Airport()
        {
            delete R;
        }

};


class City
{
    protected:
        int C_ID;
        string C_Name;
        Airport *A;
        Aeroplane *Ap;
    public:
        City()
        {
            C_ID = 0;
            C_Name = "NULL";
            A = new Airport[2];
            A[0].set_A(1,"South");
            A[1].set_A(2,"North");
        }
        City(int id, string name)
        {
            C_ID = id;
            C_Name = name;
        }
        void set_City(int cid, string cname)
        {
            C_ID = cid;
            C_Name = cname;
        }
        int get_CID()
        {
            return C_ID;
        }
        string get_CName()
        {
            return C_Name;
        }
        ~City()
        {
            delete A,Ap;
        }


};


class Seats
{
    private:
        bool Status;
        Passenger* P;
    public:
        Seats()
        {
            Status = true;
            this->P = new Passenger();
        }
        void set_status(bool set)
        {
            Status = set;
        }
        bool get_Status()
        {
            return Status;
        }
        ~Seats()
        {
            delete P;
        }  
};

class Payment
{
    private:
        double Hourly_Cost;
        double Tax;
        double Total;
    public:
        Payment()
        {
            Hourly_Cost = 0;
            Hourly_Cost = 0;
            Tax = 0.0;
        }
        Payment(double HC,double tax,double T)
        {
            Hourly_Cost = HC;
            Tax = tax;
            Total = T;
        }
        void set_HourlyCost(double HCL)
        {
            Hourly_Cost = HCL;
        }
        void set_Tax(double LT)
        {
            Tax = LT;
        }
        void set_Total(double T)
        {
            Total = T;
        }
        double get_Total()
        {
            return Total;
        }
        double get_HourlyCost()
        {
            return Hourly_Cost;
        }
        double get_Tax()
        {
            return Tax;
        }
        int set_Payment(Seats C[] ,string type, double h)
        {

            if(type == "Local")
            {
                for(int i = 0; i<50; i++)
                {
                    if(C[i].get_Status()==true)
                    {
                        this->Hourly_Cost = 10000;
                        this->Tax = (5/100)*10000;
                        this->Total = this->Hourly_Cost + this->Tax;
                    } 
                }
            }

            if(type == "International")
            {
                for(int i = 0; i<10; i++)
                {
                    if(C[i].get_Status()==true)
                    {
                        this->Hourly_Cost = 20000;
                        this->Tax = (5/100)*20000;
                        this->Total = this->Hourly_Cost + this->Tax;
                    } 
                }
            }
            return this->Total;
        }
};

class Booking
{
    private:
        Seats *Economy_Seats;
        Seats *Business_Seats;
        bool Country_Covid_Status;
        Payment* Ticket;
        int s_no;
    public:
        Booking()
        {
            Economy_Seats = new Seats[50];
            Business_Seats = new Seats[10];
            Country_Covid_Status = false;
            this->Ticket = new Payment();
        }
        void Set_No(int n)
        {
            s_no = n;
        }
        int getseat_no()
        {
            return s_no;
        }
        bool Set_Seat()
        {
            for(int i = 0; i<50; i++)
            {
                this->Set_No(i);
                Economy_Seats[i].set_status(false);
            }
            for(int i = 0; i<10; i++)
            {
                this->Set_No(i);
                Business_Seats[i].set_status(false);
            }

            srand(time(NULL));
            int seat;
            int seat1;
            int Option;
            bool Check;
            Payment P;
            cout<<"\n1. Economy Class"<<endl;
            cout<<"2. Business Class"<<endl;
            cout<<"\nPick a Class"<<endl;
            cin>>Option;

            switch(Option)
            {
                case 1:
                    do
                    {
                        seat = rand()%50+1;
                    }while(Economy_Seats[seat].get_Status()==true || seat == seat + 1);

                    for(int i = 0; i<50; i++)
                    {
                        if(seat == i)
                        {
                            Check = true;
                            Economy_Seats[i].set_status(Check);
                        }
                        else
                        {
                            Check = false;
                        }
                    }
                    if(Check = true)
                    return true;
                    else
                    return false;
                    break;
                case 2:
                    do
                    {
                        seat1 = rand()%10+1;
                    }while(Business_Seats[seat1].get_Status()==true);

                    for(int i = 0; i<10; i++)
                    {
                        if(seat == i)
                        {
                            Check =  true;
                            Business_Seats[i].set_status(Check);
                        }
                        else
                        {
                            Check =  false;
                        }
                    }
                    if(Check = true)
                    return true;
                    else
                    return false;
                    break;
            }
            
        }
        int set_Payment(string type, double h)
        {
            Payment P;
            int tax;
            int total;
            if(type == "Local")
            {
                P.set_HourlyCost(10000);
                tax = (5/100)*10000;
                P.set_Tax(tax);
                total = (P.get_HourlyCost() * h) + P.get_Tax();
                P.set_Total(total);        
            }

            if(type == "International")
            {
                P.set_HourlyCost(20000);
                tax = (10/100)*20000;
                P.set_Tax(tax);
                total = (P.get_HourlyCost() * h) + P.get_Tax();
                P.set_Total(total);
                
            }
            return P.get_Total();
        }
        ~Booking()
        {
            delete Economy_Seats, Business_Seats,Ticket;
        }
};

class Time
{
    protected:
        int Hour;
        int Minutes;
    public:
        Time()
        {
            Hour = 0;
            Minutes = 0;
        }
        Time(int h, int m)
        {
            Hour = h;
            Minutes = m;
        }
        void settime(int h, int m)
        {
            Hour = h;
            Minutes = m;
        }
        int getHours()
        {
            return Hour;
        }
        int getMinutes()
        {
            return Minutes;
        }
};


class Flight_Scedual: public City, Country
{
    private:
        string Loc_Int;
        double Flight_Duration;
        string Arrival_Time;
        string Departure_Time;
        string Destination;
        string Destination_Airport;
        string Current_Aiport;
        Booking *booking;
        Aeroplane *Ap;
        bool status;
    public:
        Flight_Scedual()
        {
            Loc_Int = "NULL";
            Flight_Duration = 0;
            Destination = "NULL";
            Destination_Airport = "NULL";
            Current_Aiport = "NULL";
            this->booking = new Booking();
        }
        Flight_Scedual(string L_I, double FD, string AT, string DT, string D, string DA, string CA, string city, int cid, bool C)
        {
            Loc_Int = L_I;
            Flight_Duration = FD;
            Arrival_Time = AT;
            Departure_Time = DT;
            Destination = D;
            Destination_Airport = DA;
            Current_Aiport = CA;
            status = C;

        }
        void set_Flight(string L_I, double FD, string AT, string DT, string D, string DA, string CA, string city, int cid, bool C)
        {
            Loc_Int = L_I;
            Flight_Duration = FD;
            Departure_Time = DT;
            Destination = D;
            Destination_Airport = DA;
            Current_Aiport = CA;
            C_Name = city;
            C_ID = cid;
            status = C;
        }
        void set_Status(bool C)
        {
            status = C;
        }
        bool get_Status()
        {
            return status;
        }
        void set_LocInt(string L_I)
        {
            Loc_Int = L_I;
        }
        void set_FlightD(double FD)
        {
            Flight_Duration = FD;
        }
        void set_ArrivalT(string AT)
        {
            Arrival_Time = AT;
        }
        void set_DepartureT(string DT)
        {
            Departure_Time = DT;
        }
        void set_DestiantionA(string DA)
        {
            Destination_Airport = DA;
        }
        void set_Destination(string D)
        {
            Destination = D;
        }
        void set_CurrentA(string CA)
        {
            Current_Aiport = CA;
        }
        void set_city(string C)
        {
            C_Name = C;
        }
        string get_city()
        {
            return C_Name;
        }
        void set_Cityid(int id)
        {
            C_ID = id;
        }
        int get_cid()
        {
            return C_ID;
        }
        string get_LocInt()
        {
            return Loc_Int;
        }
        double get_FlightD()
        {
            return Flight_Duration;
        }
        string get_ArrivalT()
        {
            return Arrival_Time;
        }
        string get_DepartureT()
        {
            return Departure_Time;
        }
        string get_DestiantionA()
        {
            return Destination_Airport;
        }
        string get_Destination()
        {
            return Destination;
        }
        string get_CurrentA()
        {
            return Current_Aiport;
        }
        void Addflight(Flight_Scedual FS[], Country C[], City cit[], int Size)
        {
            Flight_Scedual *F = new Flight_Scedual[Size+1];

            for(int i = 0; i<Size;i++)
            {
                F[i].set_DepartureT(FS[i].get_DepartureT());
                F[i].set_DestiantionA(FS[i].get_DestiantionA());
                F[i].set_Destination(FS[i].get_Destination());
                F[i].set_LocInt(FS[i].get_LocInt());
                F[i].set_CurrentA(FS[i].get_CurrentA());
                F[i].set_city(FS[i].get_city());
                F[i].set_ArrivalT(FS[i].get_ArrivalT());
                F[i].set_Status(FS[i].get_Status());
                F[i].set_FlightD(FS[i].get_FlightD());
            }

                    cout<<"\nEnter Flight type(Local,International)"<<endl;
                    cin>>Loc_Int;
                    FS[Size+1].set_LocInt(Loc_Int);
                    if(Loc_Int == "Local")
                    {
                        cout<<"Enter Destination Airport"<<endl;
                        cin>>Destination_Airport;
                        FS[Size+1].set_DestiantionA(Destination_Airport);
                        cout<<"\nEnter the City from where the Flight will take off"<<endl;
                        cin>>C_Name;
                        FS[Size+1].set_city(C_Name);
                        Failed:
                        cout<<"Enter Destiantion"<<endl;
                        cin>>Destination;
                        for(int i = 0; i<25; i++)
                        {
                            if(Destination == C[i].get_CntName())
                            {
                                cout<<"Local flights can not be assigned to a country, please select a city"<<endl;
                                goto Failed;
                            }
                            FS[Size+1].set_Destination(Destination);
                        }
                    }
                    else
                    {
                        Failed1:
                        cout<<"Enter Destiantion"<<endl;
                        cin>>Destination;
                        for(int i = 0; i<25; i++)
                        {
                            if(!(Destination == C[i].get_CntName()))
                            {
                                cout<<"International flights can not be assigned to a city, please select a country"<<endl;
                                goto Failed1;
                            }
                            FS[Size+1].set_Destination(Destination);
                        }
                    }
                    cout<<"Enter Airport of takeoff (Norht,South)"<<endl;
                    cin>>Current_Aiport;
                    cout<<"Enter Departure Time"<<endl;
                    cin>>Departure_Time;
                    cout<<"Enter Estimated Arrival Time"<<endl;
                    cin>>Arrival_Time;
                    cout<<"Enter Estimated Duration of journey"<<endl;
                    cin>>Flight_Duration;

                    FS[Size+1].set_CurrentA(Current_Aiport);
                    FS[Size+1].set_DepartureT(Departure_Time);
                    FS[Size+1].set_ArrivalT(Arrival_Time);
                    FS[Size+1].set_FlightD(Flight_Duration);
                    FS[Size+1].set_Status(true);
        }
        void Cancel_Flight(Flight_Scedual FS[], int Size)
        {
            string city;
            Booking B;
            cout<<"From which city do you want tp remove the flight"<<endl;
            cin>>city;
            for(int i = 0; i<Size; i++)
            {
                 if(city == FS[i].get_city())
                    {
                        if(FS[i].get_Status()==true)
                        {
        
                            cout<<"\n\nFlight Type: "<<FS[i].get_LocInt()<<endl;
                            if(FS[i].get_LocInt()=="Local")
                            {
                                cout<<"Destination: "<<FS[i].get_Destination()<<endl;
                                cout<<"Destination Airport: "<<FS[i].get_DestiantionA()<<endl;
                                cout<<"Current Airport: "<<FS[i].get_CurrentA()<<endl;
                                cout<<"Departure Time: "<<FS[i].get_DepartureT()<<endl;
                                cout<<"Estimated Flight Duration: "<<FS[i].get_FlightD()<<endl;
                                cout<<"Estimated Arrival time at Destination: "<<FS[i].get_ArrivalT()<<endl;
                                cout<<"Price of Flight: "<<B.set_Payment("Local",FS[i].get_FlightD())<<endl;
                            }
                            else
                            {
                                cout<<"Destination: "<<FS[i].get_Destination()<<endl;
                                cout<<"Current Airport: "<<FS[i].get_CurrentA()<<endl;
                                cout<<"Departure Time: "<<FS[i].get_DepartureT()<<endl;
                                cout<<"Estimated Flight Duration: "<<FS[i].get_FlightD()<<endl;
                                cout<<"Estimated Arrival time at Destination: "<<FS[i].get_ArrivalT()<<endl;
                                cout<<"Price of Flight: "<<B.set_Payment("International",FS[i].get_FlightD())<<endl;
                            }
                        }
                    }
                
            }

            Cancel:
            cout<<"Which Flight do you want to remove(Select by Destination)"<<endl;
            cin>>Destination;
            for(int i = 0; i<Size; i++)
            {
                 if(Destination == FS[i].get_Destination() && city == FS[i].get_city())
                    {
                        if(FS[i].get_Status()==false)
                        {
                            cout<<"The Flight has already been cancelled"<<endl;
                            return;
                        }
                        else
                        {
                            FS[i].set_Status(false);
                        }
                    }
                }
            }
            void Change_Scedual(Flight_Scedual FS[], int Size)
            {
                int Option;
                int city;
                string city_s;
                Booking B;
                string C_Scedual;
                string D;
                string DT;
                double ET;

                    cout<<"1. Peshawar"<<endl;
                    cout<<"2. Islamabad"<<endl;
                    cout<<"3. Karachi"<<endl;
                    cout<<"4. Quetta"<<endl;
                    cout<<"5. Lahore"<<endl;
                    cout<<"\nSelect city to change Flight Sceduals"<<endl;
                    cin>>city;
                    

                    switch(city)
                    {
                        case 1:
                        city_s = "Peshawar";
                        break;
                        case 2:
                        city_s = "Islamabad";
                        break;
                        case 3:
                        city_s = "Karachi";
                        break;
                        case 4:
                        city_s = "Quetta";
                        break;
                        case 5:
                        city_s = "Lahore";
                        break;
                    }
                
                for(int i = 0; i<Size; i++)
                {
                        if(city_s == FS[i].get_city())
                        {
                            if(FS[i].get_Status()==true)
                                {
                                    cout<<"\n\nFlight Type: "<<FS[i].get_LocInt()<<endl;
                                    if(FS[i].get_LocInt()=="Local")
                                    {
                                        cout<<"Destination: "<<FS[i].get_Destination()<<endl;
                                        cout<<"Destination Airport: "<<FS[i].get_DestiantionA()<<endl;
                                        cout<<"Current Airport: "<<FS[i].get_CurrentA()<<endl;
                                        cout<<"Departure Time: "<<FS[i].get_DepartureT()<<endl;
                                        cout<<"Estimated Flight Duration: "<<FS[i].get_FlightD()<<endl;
                                        cout<<"Estimated Arrival time at Destination: "<<FS[i].get_ArrivalT()<<endl;
                                        cout<<"Price of Flight: "<<B.set_Payment("Local",FS[i].get_FlightD())<<endl;
                                    }
                                    else
                                    {
                                        cout<<"Destination: "<<FS[i].get_Destination()<<endl;
                                        cout<<"Current Airport: "<<FS[i].get_CurrentA()<<endl;
                                        cout<<"Departure Time: "<<FS[i].get_DepartureT()<<endl;
                                        cout<<"Estimated Flight Duration: "<<FS[i].get_FlightD()<<endl;
                                        cout<<"Estimated Arrival time at Destination: "<<FS[i].get_ArrivalT()<<endl;
                                        cout<<"Price of Flight: "<<B.set_Payment("International",FS[i].get_FlightD())<<endl;
                                    }
                                }
                        }
                    
                }
                Change:
                cout<<"\nSelect by Destination the Flight you want to rescedual"<<endl;
                cin>>C_Scedual;

                    for(int i = 0; i<15; i++)
                    {
                        if(FS[i].get_city()==city_s && FS[i].get_Destination()==C_Scedual)
                        {
                            cout<<"\nEnter Departure Time"<<endl;
                            cin>>DT;
                            FS[i].set_DepartureT(DT);
                            cout<<"Enter Arrival Time"<<endl;
                            cin>>D;
                            FS[i].set_ArrivalT(D);
                            cout<<"Flight Duration"<<endl;
                            cin>>ET;
                            FS[i].set_FlightD(ET);
                        }
                    }
                    cout<<"\n1. Chnage Scedual of Another Flight"<<endl;
                    cout<<"2. exit"<<endl;
                    cin>>Option;

                    switch(Option)
                    {
                        case 1:
                            goto Change;
                        case 2:
                            break;
                    }
            }
            void View_All_Flights(Flight_Scedual FS[], int Size)
            {
                Booking B;
                 for(int i = 0; i<Size; i++)
                {
                    if(FS[i].get_Status()==true)
                    {
                            cout<<"\n\nFlight Type: "<<FS[i].get_LocInt()<<endl;
                            if(FS[i].get_LocInt()=="Local")
                            {
                                cout<<"\n\t\tScedual for "<<FS[i].get_city()<<" today"<<endl;
                                cout<<"Destination: "<<FS[i].get_Destination()<<endl;
                                cout<<"Destination Airport: "<<FS[i].get_DestiantionA()<<endl;
                                cout<<"Current Airport: "<<FS[i].get_CurrentA()<<endl;
                                cout<<"Departure Time: "<<FS[i].get_DepartureT()<<endl;
                                cout<<"Estimated Flight Duration: "<<FS[i].get_FlightD()<<endl;
                                cout<<"Estimated Arrival time at Destination: "<<FS[i].get_ArrivalT()<<endl;
                                cout<<"Price of Flight: "<<B.set_Payment("Local",FS[i].get_FlightD())<<endl;
                            }
                            else
                            {
                                cout<<"Destination: "<<FS[i].get_Destination()<<endl;
                                cout<<"Current Airport: "<<FS[i].get_CurrentA()<<endl;
                                cout<<"Departure Time: "<<FS[i].get_DepartureT()<<endl;
                                cout<<"Estimated Flight Duration: "<<FS[i].get_FlightD()<<endl;
                                cout<<"Estimated Arrival time at Destination: "<<FS[i].get_ArrivalT()<<endl;
                                cout<<"Price of Flight: "<<B.set_Payment("International",FS[i].get_FlightD())<<endl;
                            }
                    }
                    else
                    {
                        continue;
                    }
                }
            }
};



class NPAFS
{
    private:
        City* city;
        Country* country;
        Flight_Scedual* Flights;
        Aeroplane *Ap;
    public:
        NPAFS()
        {
            int Size = 15;
            city = new City[5];
            country = new Country[25];
            Flights = new Flight_Scedual[Size];
            Ap = new Aeroplane[20];
            Ap[0].set_Apid(1);
            Ap[1].set_Apid(2);
            Ap[2].set_Apid(3);
            Ap[3].set_Apid(4);
            Ap[4].set_Apid(5);
            Ap[5].set_Apid(6);
            Ap[6].set_Apid(7);
            Ap[7].set_Apid(8);
            Ap[8].set_Apid(9);
            Ap[9].set_Apid(10);
            Ap[10].set_Apid(11);
            Ap[11].set_Apid(12);
            Ap[12].set_Apid(13);
            Ap[13].set_Apid(14);
            Ap[14].set_Apid(15);
            Ap[15].set_Apid(16);
            Ap[16].set_Apid(17);
            Ap[17].set_Apid(18);
            Ap[18].set_Apid(19);
            Ap[19].set_Apid(20);

            city[0].set_City(1,"Islamabad");
            city[1].set_City(2,"Peshawar");
            city[2].set_City(3,"Karachi");
            city[3].set_City(4,"Quetta");
            city[4].set_City(5,"Lahore");

            country[0].set_Country(1,"Nepal",true);
            country[1].set_Country(2,"India",true);
            country[2].set_Country(3,"Bangladesh",true);
            country[3].set_Country(4,"Afghanistan",true);
            country[4].set_Country(5,"Iran",false);
            country[5].set_Country(6,"China",true);
            country[6].set_Country(7,"Japan",false);
            country[7].set_Country(8,"Noth Korea",false);
            country[8].set_Country(9,"Souht Korea",true);
            country[9].set_Country(10,"Srilanka",true);
            country[10].set_Country(11,"Uzbekistan",true);
            country[11].set_Country(12,"Tajikistan",true);
            country[12].set_Country(13,"England",false);
            country[13].set_Country(14,"Germany",false);
            country[14].set_Country(15,"Spain",false);
            country[15].set_Country(16,"Netherlands",false);
            country[16].set_Country(17,"Portugal",false);
            country[17].set_Country(18,"France",false);
            country[18].set_Country(19,"UAE",true);
            country[19].set_Country(20,"Saudi Arabia",false);
            country[20].set_Country(21,"Iraq",true);
            country[21].set_Country(22,"Qatar",false);
            country[22].set_Country(23,"Lebanon",true);
            country[23].set_Country(24,"Turkey",true);
            country[24].set_Country(25,"Russia",true);

            //Peshawar Flights
            Flights[0].set_LocInt("Local");
            Flights[0].set_city("Peshawar");
            Flights[0].set_Destination("Islamabad");
            Flights[0].set_DestiantionA("South");
            Flights[0].set_DepartureT("10:30");
            Flights[0].set_CurrentA("North");
            Flights[0].set_FlightD(0.5);
            Flights[0].set_ArrivalT("11:30");
            Flights[0].set_Status(true);

            Flights[1].set_LocInt("Local");
            Flights[1].set_city("Peshawar");
            Flights[1].set_Destination("Karachi");
            Flights[1].set_DestiantionA("South");
            Flights[1].set_DepartureT("12:30");
            Flights[1].set_CurrentA("South");
            Flights[1].set_FlightD(1.5);
            Flights[1].set_ArrivalT("14:00");
            Flights[1].set_Status(true);


            Flights[2].set_LocInt("International");
            Flights[2].set_city("Peshawar");
            Flights[2].set_CurrentA("North");
            Flights[2].set_Destination("India");
            Flights[2].set_DepartureT("15:30");
            Flights[2].set_FlightD(1.59);
            Flights[2].set_ArrivalT("16:29");
            Flights[2].set_Status(true);

            //Islamabad Flights
            Flights[3].set_LocInt("Local");
            Flights[3].set_city("Islamabad");
            Flights[3].set_Destination("Peshawar");
            Flights[3].set_DestiantionA("North");
            Flights[3].set_DepartureT("10:30");
            Flights[3].set_CurrentA("North");
            Flights[3].set_FlightD(0.5);
            Flights[3].set_ArrivalT("11:30");
            Flights[3].set_Status(true);

            Flights[4].set_LocInt("Local");
            Flights[4].set_city("Islamabad");
            Flights[4].set_Destination("Lahore");
            Flights[4].set_DestiantionA("South");
            Flights[4].set_DepartureT("12:30");
            Flights[4].set_CurrentA("North");
            Flights[4].set_FlightD(1.5);
            Flights[4].set_ArrivalT("14:00");
            Flights[4].set_Status(true);

            
            Flights[5].set_LocInt("International");
            Flights[5].set_city("Islamabad");
            Flights[5].set_Destination("Turkey");
            Flights[5].set_CurrentA("South");
            Flights[5].set_DepartureT("16:30");
            Flights[5].set_FlightD(3.5);
            Flights[5].set_ArrivalT("20:00");
            Flights[5].set_Status(true);

            // Lahore FLights
            Flights[6].set_LocInt("Local");
            Flights[6].set_city("Lahore");
            Flights[6].set_Destination("Peshawar");
            Flights[6].set_DestiantionA("North");
            Flights[6].set_DepartureT("10:30");
            Flights[6].set_CurrentA("North");
            Flights[6].set_FlightD(1);
            Flights[6].set_ArrivalT("11:30");
            Flights[6].set_Status(true);

            Flights[7].set_LocInt("Local");
            Flights[7].set_city("Lahore");
            Flights[7].set_Destination("Islamabad");
            Flights[7].set_DestiantionA("South");
            Flights[7].set_DepartureT("12:30");
            Flights[7].set_CurrentA("North");
            Flights[7].set_FlightD(0.75);
            Flights[7].set_ArrivalT("13:20");
            Flights[7].set_Status(true);
            
            Flights[8].set_LocInt("International");
            Flights[8].set_city("Lahore");
            Flights[8].set_Destination("Iran");
            Flights[8].set_CurrentA("North");
            Flights[8].set_DepartureT("16:30");
            Flights[8].set_FlightD(1.65);
            Flights[8].set_ArrivalT("18:40");
            Flights[8].set_Status(true);

            //Karachi Flights
            Flights[9].set_LocInt("Local");
            Flights[9].set_city("Karachi");
            Flights[9].set_Destination("Peshawar");
            Flights[9].set_DestiantionA("South");
            Flights[9].set_DepartureT("10:30");
            Flights[9].set_CurrentA("North");
            Flights[9].set_FlightD(1.5);
            Flights[9].set_ArrivalT("12:00");
            Flights[9].set_Status(true);

            Flights[10].set_LocInt("Local");
            Flights[10].set_city("Karachi");
            Flights[10].set_Destination("Islamabad");
            Flights[10].set_DestiantionA("South");
            Flights[10].set_DepartureT("12:30");
            Flights[10].set_CurrentA("South");
            Flights[10].set_FlightD(1);
            Flights[10].set_ArrivalT("13:30");
            Flights[10].set_Status(true);
            
            Flights[11].set_LocInt("International");
            Flights[11].set_city("Karachi");
            Flights[11].set_Destination("Qatar");
            Flights[11].set_CurrentA("North");
            Flights[11].set_DepartureT("16:30");
            Flights[11].set_FlightD(2.05);
            Flights[11].set_ArrivalT("18:40");
            Flights[11].set_Status(true);

            //Quetta Flights
            Flights[12].set_LocInt("Local");
            Flights[12].set_city("Quetta");
            Flights[12].set_Destination("Islamabad");
            Flights[12].set_DestiantionA("South");
            Flights[12].set_DepartureT("10:30");
            Flights[12].set_CurrentA("North");
            Flights[12].set_FlightD(1.5);
            Flights[12].set_ArrivalT("12:00");
            Flights[12].set_Status(true);

            Flights[13].set_LocInt("Local");
            Flights[13].set_city("Quetta");
            Flights[13].set_Destination("Peshawar");
            Flights[13].set_DestiantionA("North");
            Flights[13].set_DepartureT("12:30");
            Flights[13].set_CurrentA("South");
            Flights[13].set_FlightD(1);
            Flights[13].set_ArrivalT("13:30");
            Flights[13].set_Status(true);
            
            Flights[14].set_LocInt("International");
            Flights[14].set_city("Quetta");
            Flights[14].set_Destination("England");
            Flights[14].set_CurrentA("North");
            Flights[14].set_DepartureT("16:30");
            Flights[14].set_FlightD(6.81);
            Flights[14].set_ArrivalT("00:25");
            Flights[14].set_Status(true);

        }
        void Registred_Menu()
        {
            int Option;
            string F_Select;
            int city;
            Booking B;
            string city_s;
            int pin;

            Return:
            cout<<"\n";
            cout<<"1. Book a flight"<<endl;
            cout<<"2. Reserve a Flight"<<endl;
            cout<<"3. Log out"<<endl;
            
            cout<<"\nSelect one of the Options above"<<endl;
            cin>>Option;

            switch(Option)
            {
                case 1:
                    cout<<"1. Peshawar"<<endl;
                    cout<<"2. Islamabad"<<endl;
                    cout<<"3. Karachi"<<endl;
                    cout<<"4. Quetta"<<endl;
                    cout<<"5. Lahore"<<endl;
                    cout<<"\nWhich City do you want to fly from"<<endl;
                    cin>>city;

                    switch(city)
                    {
                        case 1:
                        city_s = "Peshawar";
                        break;
                        case 2:
                        city_s = "Islamabad";
                        break;
                        case 3:
                        city_s = "Karachi";
                        break;
                        case 4:
                        city_s = "Quetta";
                        break;
                        case 5:
                        city_s = "Lahore";
                        break;
                    }

                    cout<<"\n\t\tFlight Scedual for "<<city<<" today"<<endl;
                    for(int i = 0; i<15; i++ )
                    {
                        if(city_s == Flights[i].get_city())
                        {
                            cout<<"\nFlight Type: "<<Flights[i].get_LocInt()<<endl;
                            if(Flights[i].get_LocInt()=="Local")
                            {
                                if(Flights[i].get_Status()==true)
                                {
                                cout<<"Destination: "<<Flights[i].get_Destination()<<endl;
                                cout<<"Destination Airport: "<<Flights[i].get_DestiantionA()<<endl;
                                cout<<"Current Airport: "<<Flights[i].get_CurrentA()<<endl;
                                cout<<"Departure Time: "<<Flights[i].get_DepartureT()<<endl;
                                cout<<"Estimated Flight Duration: "<<Flights[i].get_FlightD()<<endl;
                                cout<<"Estimated Arrival time at Destination: "<<Flights[i].get_ArrivalT()<<endl;
                                cout<<"Price of Flight: "<<B.set_Payment("Local",Flights[i].get_FlightD())<<endl;
                                }
                            }
                            else
                            {
                                cout<<"Destination: "<<Flights[i].get_Destination()<<endl;
                                cout<<"Current Airport: "<<Flights[i].get_CurrentA()<<endl;
                                cout<<"Departure Time: "<<Flights[i].get_DepartureT()<<endl;
                                cout<<"Estimated Flight Duration: "<<Flights[i].get_FlightD()<<endl;
                                cout<<"Estimated Arrival time at Destination: "<<Flights[i].get_ArrivalT()<<endl;
                                cout<<"Price of Flight: "<<B.set_Payment("International",Flights[i].get_FlightD())<<endl;
                            }
                        }
                    }

                    Destination:
                    cout<<"\nSelect a flight By Destination"<<endl;
                    cin>>F_Select;
                    cin.ignore();

                    for(int i = 0; i<15; i++)
                    {
                        if(city_s == Flights[i].get_city())
                        {
                            if(F_Select==Flights[i].get_Destination())
                            {
                                if(B.Set_Seat())
                                {           
                                    cout<<"\nYour Flight to "<<Flights[i].get_Destination()<<" has been booked!"<<endl;
                                    cout<<endl;
                                    goto Return;
                                }
                                else
                                {
                                    cout<<"\nNo seat is Available in this flight"<<endl;
                                    cout<<"1. Select another flight"<<endl;
                                    cout<<"2. Exit"<<endl;
                                    cin>>Option;
                                    if(Option==2)
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        goto Destination;
                                    }
                                }
                            }
                        }
                        else
                        {
                            cout<<"\nFlights to this Destination are not available"<<endl;
                            goto Destination;
                        }
                    }
                    break;
                    case 2:
                    cout<<"1. Peshawar"<<endl;
                    cout<<"2. Islamabad"<<endl;
                    cout<<"3. Karachi"<<endl;
                    cout<<"4. Quetta"<<endl;
                    cout<<"5. Lahore"<<endl;
                    cout<<"\nWhich City do you want to fly from"<<endl;
                    cin>>city;

                    switch(city)
                    {
                        case 1:
                        city_s = "Peshawar";
                        break;
                        case 2:
                        city_s = "Islamabad";
                        break;
                        case 3:
                        city_s = "Karachi";
                        break;
                        case 4:
                        city_s = "Quetta";
                        break;
                        case 5:
                        city_s = "Lahore";
                        break;
                    }

                    cout<<"\n\t\tFlight Scedual for "<<city<<" today"<<endl;
                    for(int i = 0; i<15; i++ )
                    if(city_s == Flights[i].get_city())
                    {
                        cout<<"\nFlight Type: "<<Flights[i].get_LocInt()<<endl;
                        if(Flights[i].get_LocInt()=="Local")
                        {
                            cout<<"Destination: "<<Flights[i].get_Destination()<<endl;
                            cout<<"Destination Airport: "<<Flights[i].get_DestiantionA()<<endl;
                            cout<<"Current Airport: "<<Flights[i].get_CurrentA()<<endl;
                            cout<<"Departure Time: "<<Flights[i].get_DepartureT()<<endl;
                            cout<<"Estimated Flight Duration: "<<Flights[i].get_FlightD()<<endl;
                            cout<<"Estimated Arrival time at Destination: "<<Flights[i].get_ArrivalT()<<endl;
                            cout<<"Price of Flight: "<<B.set_Payment("Local",Flights[i].get_FlightD())<<endl;
                        }
                        else
                        {
                            cout<<"Destination: "<<Flights[i].get_Destination()<<endl;
                            cout<<"Current Airport: "<<Flights[i].get_CurrentA()<<endl;
                            cout<<"Departure Time: "<<Flights[i].get_DepartureT()<<endl;
                            cout<<"Estimated Flight Duration: "<<Flights[i].get_FlightD()<<endl;
                            cout<<"Estimated Arrival time at Destination: "<<Flights[i].get_ArrivalT()<<endl;
                            cout<<"Price of Flight: "<<B.set_Payment("International",Flights[i].get_FlightD())<<endl;
                        }
                    }

                    Destination1:
                    cout<<"\nSelect a flight By Destination"<<endl;
                    cin>>F_Select;
                    cin.ignore();
                    for(int i = 0; i<15; i++)
                    {
                        if(city_s == Flights[i].get_city())
                        {
                            if(F_Select==Flights[i].get_Destination())
                            {
                                if(B.Set_Seat())
                                {           
                                    cout<<"Your Flight to "<<Flights[i].get_Destination()<<" has been Reserved!"<<endl;
                                    cout<<"We have reserved seat no "<< B.getseat_no() << endl;
                                    break;
                                }
                                else
                                {
                                    cout<<"No seat is Available in this flight"<<endl;
                                    cout<<"1. Select another flight"<<endl;
                                    cout<<"2. Exit"<<endl;
                                    cin>>Option;
                                    if(Option==2)
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        goto Destination1;
                                    }   
                                }
                            }
                        }
                        else
                        {
                            cout<<"\nFlights to this Destination are not available"<<endl;
                            cout<<"1. Select another flight"<<endl;
                            cout<<"2. Exit"<<endl;
                            cin>>Option;
                            if(Option==2)
                            {
                                break;
                            }
                            else
                            {
                                goto Destination;
                            }
                        }
                    }   
                        case 3:
                        return;
                        break;
            }

        }
        void Guest_Menu()
        {
            Booking B;
            Payment P;
            int Option;
            string F_Select;
            int city;
            string city_s;

            
                    cout<<"1. Peshawar"<<endl;
                    cout<<"2. Islamabad"<<endl;
                    cout<<"3. Karachi"<<endl;
                    cout<<"4. Quetta"<<endl;
                    cout<<"5. Lahore"<<endl;
                    cout<<"\nWhich City do you want to View the Flights"<<endl;
                    cin>>city;

                    switch(city)
                    {
                        case 1:
                        city_s = "Peshawar";
                        break;
                        case 2:
                        city_s = "Islamabad";
                        break;
                        case 3:
                        city_s = "Karachi";
                        break;
                        case 4:
                        city_s = "Quetta";
                        break;
                        case 5:
                        city_s = "Lahore";
                        break;
                    }

                    cout<<"\n\t\tFlight Scedual for "<<city<<" today"<<endl;
                    for(int i = 0; i<15; i++ )
                    if(city_s == Flights[i].get_city())
                    {
                        cout<<"\n\nFlight Type: "<<Flights[i].get_LocInt()<<endl;
                        if(Flights[i].get_LocInt()=="Local")
                        {
                            cout<<"Destination: "<<Flights[i].get_Destination()<<endl;
                            cout<<"Destination Airport: "<<Flights[i].get_DestiantionA()<<endl;
                            cout<<"Current Airport: "<<Flights[i].get_CurrentA()<<endl;
                            cout<<"Departure Time: "<<Flights[i].get_DepartureT()<<endl;
                            cout<<"Estimated Flight Duration: "<<Flights[i].get_FlightD()<<endl;
                            cout<<"Estimated Arrival time at Destination: "<<Flights[i].get_ArrivalT()<<endl;
                            cout<<"Price of Flight: "<<B.set_Payment("Local",Flights[i].get_FlightD())<<endl;
                        }
                        else
                        {
                            cout<<"Destination: "<<Flights[i].get_Destination()<<endl;
                            cout<<"Current Airport: "<<Flights[i].get_CurrentA()<<endl;
                            cout<<"Departure Time: "<<Flights[i].get_DepartureT()<<endl;
                            cout<<"Estimated Flight Duration: "<<Flights[i].get_FlightD()<<endl;
                            cout<<"Estimated Arrival time at Destination: "<<Flights[i].get_ArrivalT()<<endl;
                            cout<<"Price of Flight: "<<B.set_Payment("International",Flights[i].get_FlightD())<<endl;
                        }
                    }

                    
        }
        void Admin_Menu()
        {
            Flight_Scedual FS;
            int Option;
            static int Size = 15;
            Restore:
            cout<<"\n\tAdmin Menu"<<endl;
            cout<<"1. Add a Flight"<<endl;
            cout<<"2. Cancel Flight"<<endl;
            cout<<"3. Change Flight Scedual"<<endl;
            cout<<"4. View All Flights"<<endl;
            cout<<"5. Exit"<<endl;

            cout<<"Select one of the Options above"<<endl;
            cin>>Option;

            switch (Option)
            {
            case 1:
            Size++;
            FS.Addflight(Flights,country,city,Size);
            goto Restore;
            break;

            case 2:
            FS.Cancel_Flight(Flights,Size);
            goto Restore;
            break;

            case 3:
            FS.Change_Scedual(Flights,Size);
            goto Restore;
            break;

            case 4:
            FS.View_All_Flights(Flights,Size);
            goto Restore;
            break;

            case 5:
            break;
        }

        }
        ~NPAFS()
        {
            delete city,country,Flights;
        }
};


int main()
{
    Passenger P;
    Admin A;
    NPAFS N;
   int Optionww;
    int Option1;

    cout<<"\t\tNeW Pakistan Airline Flight System"<<endl;
    Return:
    cout<<"1. Login as a user"<<endl;
    cout<<"2. Login as admin"<<endl;
    No_Account:
    cout<<"3. Continue as guest"<<endl;
    cout<<"4. Sign up"<<endl;
    cout<<"5. Exit"<<endl;

    cout<<"Select one of the option above"<<endl;
    cin>>Option1;

    switch(Option1)
    {
        case 1:
        if(P.Login())
        {
            cout<<"\n\tLogged in"<<endl;
            N.Registred_Menu();
            goto Return;

        }
        else
        {
            cout<<"\nFailed to login"<<endl;
            cout<<"1.Try Again"<<endl;
            cout<<"2. Sign up"<<endl;
            cin>>Optionww;

            switch(Optionww)
            {
                case 1:
                    goto Return;
                case 2:
                    goto No_Account;
            }
            
        }
        break;

        case 2:
        if(A.login())
        {
            cout<<"\n\tLoggend in"<<endl;
            N.Admin_Menu();
            goto Return;
        }
        else
        {
            cout<<"\nIncorrect Password"<<endl;
            goto Return;
        }
        break;

        case 3:
        N.Guest_Menu();
        goto Return;
        break;

        case 4:
        P.Register();
        goto Return;
        break;

        case 5:
        exit(0);

    }

}